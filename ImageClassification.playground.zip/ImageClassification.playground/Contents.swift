import Cocoa
import CreateMLUI


let builder = MLImageClassifierBuilder()
builder.showInLiveView()


//add your own training data to generate an mlmodel file using this image classifier and save at disk 


//To use in CORE ML enabled app
//let model = try VNCoreMLModel(for: AnimalClassifier().model)
