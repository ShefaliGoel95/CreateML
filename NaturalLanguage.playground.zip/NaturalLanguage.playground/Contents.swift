import Cocoa
import CreateML
import Foundation
import NaturalLanguage

//create a constant called data which is a type of MLDataTable to our spam.json file. MLDataTable is a brand new object used to create a table determined to train or evaluate a ML model
guard let trainingCSV = Bundle.main.url(forResource: "generated", withExtension: "json") else {
    fatalError()
}

// load the CSV file into a data table
var data = try MLDataTable(contentsOf: trainingCSV)


//split our data into trainingData and testingData, the ratio is 80-20
//the seed is 5. The seed refers to where the classifier should start from.
let (trainingData, testingData) = data.randomSplit(by: 0.8, seed: 5)


//define a MLTextClassifier called spamClassifier with our training data, defining what values of the data are text and what values are labels.
let spamClassifier = try MLTextClassifier(trainingData: trainingData, textColumn: "text", labelColumn: "label")

//create two variables called trainingAccuracy and validationAccuracy used to determine how accurate our classifier is. In the side pane, you’ll be able to see the percentage.
let trainingAccuracy = (1.0 - spamClassifier.trainingMetrics.classificationError) * 100
let validationAccuracy = (1.0 - spamClassifier.validationMetrics.classificationError) * 100

//how the evaluation performed
let evaluationMetrics = spamClassifier.evaluation(on: testingData)
let evaluationAccuracy = (1.0 - evaluationMetrics.classificationError) * 100


//create some metadata for the ML model like the author, description, and version
let metadata = MLModelMetadata(author: "Author Name"  , shortDescription: "A model trained to classify spam messages", version: "1.0")

var outputURL = URL(fileURLWithPath: "/Users/shefali.goel/Desktop/Create ML folders/TextClassification.mlmodel")

//use the write() function to save the model to the location of our choice
try spamClassifier.write(to: outputURL , metadata: metadata)


let sentimentPredictor = try NLModel(mlModel: spamClassifier.model)
let res = sentimentPredictor.predictedLabel(for: "It is amazing.")
print(res ?? "__")
